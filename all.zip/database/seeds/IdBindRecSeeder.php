<?php

use Illuminate\Database\Seeder;

class IdBindRecSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data = [
            [
                'consumer_id'        => 'myrepi001',
                'one_cp_id'          => 'onecp0001',
                'bind_customer_id'   => '0001',
                'bind_user_id'       => 'yahoo_user_id_0001',
                'extra_info_01'      => null,
                'extra_info_02'      => null,
                'extra_info_03'      => null,
                'extra_info_04'      => null,
                'extra_info_05'      => null,
                'deleted_flg'        => 0,
                'binded_date'        => '2018-05-22',
                'updated_date'       => '2018-05-22',
                'deleted_date'       => null
            ],[
                'consumer_id'        => 'myrepi001',
                'one_cp_id'          => 'onecp0001',
                'bind_customer_id'   => '0002',
                'bind_user_id'       => 'cainz_user_id_0001',
                'extra_info_01'      => null,
                'extra_info_02'      => null,
                'extra_info_03'      => null,
                'extra_info_04'      => null,
                'extra_info_05'      => null,
                'deleted_flg'        => 0,
                'binded_date'        => '2018-05-22',
                'updated_date'       => '2018-05-22',
                'deleted_date'       => null
            ],[
                'consumer_id'        => 'myrepi002',
                'one_cp_id'          => 'onecp0002',
                'bind_customer_id'   => '0001',
                'bind_user_id'       => 'yahoo_user_id_0002',
                'extra_info_01'      => null,
                'extra_info_02'      => null,
                'extra_info_03'      => null,
                'extra_info_04'      => null,
                'extra_info_05'      => null,
                'deleted_flg'        => 0,
                'binded_date'        => '2018-05-22',
                'updated_date'       => '2018-05-22',
                'deleted_date'       => null
            ],[
                'consumer_id'        => 'myrepi003',
                'one_cp_id'          => 'onecp0003',
                'bind_customer_id'   => '0002',
                'bind_user_id'       => 'cainz_user_id_0002',
                'extra_info_01'      => null,
                'extra_info_02'      => null,
                'extra_info_03'      => null,
                'extra_info_04'      => null,
                'extra_info_05'      => null,
                'deleted_flg'        => 0,
                'binded_date'        => '2018-05-22',
                'updated_date'       => '2018-05-22',
                'deleted_date'       => null
            ],[
                'consumer_id'        => 'myrepi004',
                'one_cp_id'          => 'onecp0004',
                'bind_customer_id'   => '0003',
                'bind_user_id'       => 'waon_user_id_0002',
                'extra_info_01'      => null,
                'extra_info_02'      => null,
                'extra_info_03'      => null,
                'extra_info_04'      => null,
                'extra_info_05'      => null,
                'deleted_flg'        => 0,
                'binded_date'        => '2018-05-22',
                'updated_date'       => '2018-05-22',
                'deleted_date'       => null
            ]
        ];
        DB::table('id_bind_recs')->truncate();
        DB::table('id_bind_recs')->insert($data);
    }
}
