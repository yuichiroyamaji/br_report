    <?php

use Illuminate\Database\Seeder;

class IdBindCustomerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data = [
            [
                'bind_customer_id'     => '0001',
                'bind_customer_name'   => 'lohaco',
                'customer_logo_01'     => 'img/yahoo_cutomer_logo01.png',
                'customer_logo_02'     => 'img/yahoo_cutomer_logo02.png',
                'customer_logo_03'     => 'img/yahoo_cutomer_logo03.png',
                'customer_logo_04'     => 'img/yahoo_cutomer_logo04.png',
                'customer_logo_05'     => 'img/yahoo_cutomer_logo05.png',
                'login_logo_01'        => 'img/yahoo_login_logo01.png',
                'login_logo_02'        => 'img/yahoo_login_logo02.png',
                'login_logo_03'        => 'img/yahoo_login_logo03.png',
                'login_logo_04'        => 'img/yahoo_login_logo04.png',
                'login_logo_05'        => 'img/yahoo_login_logo05.png',
                'display_order'        => 1,
                'status_flg'           => 1,
                'deleted_flg'          => 0,
                'binded_date'          => '2018-05-22',
                'updated_date'         => '2018-05-22',
                'deleted_date'         => null
            ],[
                'bind_customer_id'     => '0002',
                'bind_customer_name'   => 'cainz',
                'customer_logo_01'     => 'img/cainz_cutomer_logo01.png',
                'customer_logo_02'     => 'img/cainz_cutomer_logo02.png',
                'customer_logo_03'     => 'img/cainz_cutomer_logo03.png',
                'customer_logo_04'     => 'img/cainz_cutomer_logo04.png',
                'customer_logo_05'     => 'img/cainz_cutomer_logo05.png',
                'login_logo_01'        => 'img/cainz_login_logo01.png',
                'login_logo_02'        => 'img/cainz_login_logo02.png',
                'login_logo_03'        => 'img/cainz_login_logo03.png',
                'login_logo_04'        => 'img/cainz_login_logo04.png',
                'login_logo_05'        => 'img/cainz_login_logo05.png',
                'display_order'        => 2,
                'status_flg'           => 1,
                'deleted_flg'          => 0,
                'binded_date'          => '2018-05-22',
                'updated_date'         => '2018-05-22',
                'deleted_date'         => null
            ],[
                'bind_customer_id'     => '0003',
                'bind_customer_name'   => 'waon',
                'customer_logo_01'     => 'img/waon_cutomer_logo01.png',
                'customer_logo_02'     => 'img/waon_cutomer_logo02.png',
                'customer_logo_03'     => 'img/waon_cutomer_logo03.png',
                'customer_logo_04'     => 'img/waon_cutomer_logo04.png',
                'customer_logo_05'     => 'img/waon_cutomer_logo05.png',
                'login_logo_01'        => 'img/waon_login_logo01.png',
                'login_logo_02'        => 'img/waon_login_logo02.png',
                'login_logo_03'        => 'img/waon_login_logo03.png',
                'login_logo_04'        => 'img/waon_login_logo04.png',
                'login_logo_05'        => 'img/waon_login_logo05.png',
                'display_order'        => 3,
                'status_flg'           => 0,
                'deleted_flg'          => 0,
                'binded_date'          => '2018-05-22',
                'updated_date'         => '2018-05-22',
                'deleted_date'         => null
            ]
        ];
        DB::table('id_bind_customers')->truncate();
        DB::table('id_bind_customers')->insert($data);
    }
}
