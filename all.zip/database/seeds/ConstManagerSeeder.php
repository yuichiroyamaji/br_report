<?php

use Illuminate\Database\Seeder;

class ConstManagerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data = [
            [
                'class'         => 'GRS',
		        'key'           => 'login_api_url',
		        'value'         => 'https://grs-pg.com/rest/app/894/account/login',
		        'memo'          => 'マイレピログインAPIのURL',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'GRS',
		        'key'           => 'getbyurn_api_url',
		        'value'         => 'https://grs-pg.com/rest/app/894/consumer/',
		        'memo'          => 'マイレピIDをGET送信するAPIのURL',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'GRS',
		        'key'           => 'production_api_url',
		        'value'         => 'https://grs-pg.com/rest/app/894/consumer/production',
		        'memo'          => '多種パラメータで個人情報を検索取得できるAPIのURL',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'GRS',
		        'key'           => 'login_api_method',
		        'value'         => 'POST',
		        'memo'          => 'マイレピログインAPIのメソッド',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'GRS',
		        'key'           => 'getbyurn_api_method',
		        'value'         => 'GET',
		        'memo'          => 'マイレピIDをGET送信するAPIのメソッド',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'GRS',
		        'key'           => 'production_api_method',
		        'value'         => 'POST',
		        'memo'          => '多種パラメータで個人情報を検索取得できるAPIのメソッド',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'GRS',
		        'key'           => 'basic_user',
		        'value'         => 'jolt_gf_ja_jp',
		        'memo'          => 'GRS･APIの認証ユーザID',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'GRS',
		        'key'           => 'basic_pass',
		        'value'         => 'BarP2xrFs9Be',
		        'memo'          => 'GRS･APIの認証パスワード',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'GRS',
		        'key'           => 'login_api_contype',
		        'value'         => 'Content-Type: application/x-www-form-urlencoded',
		        'memo'          => 'マイレピログインAPIのヘッダーコンテントタイプ',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'GRS',
		        'key'           => 'getbyurn_api_contype',
		        'value'         => 'Content-Type: application/x-www-form-urlencoded',
		        'memo'          => 'マイレピIDをGET送信するAPIのヘッダーコンテントタイプ',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'GRS',
		        'key'           => 'production_api_contype',
		        'value'         => 'Content-Type: application/json',
		        'memo'          => '多種パラメータで個人情報を検索取得できるAPIのヘッダーコンテントタイプ',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'CURL',
		        'key'           => 'curlopt_timeout',
		        'value'         => '10',
		        'memo'          => 'CURL用TIMEOUT設定値',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'CURL',
		        'key'           => 'curlopt_proxy',
		        'value'         => 'tci-proxy.trans-cosmos.co.jp',
		        'memo'          => 'CURL用PROXYアドレス',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'CURL',
		        'key'           => 'curlopt_proxyport',
		        'value'         => '8080',
		        'memo'          => 'CURL用PROXYポート',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'YAHOO',
		        'key'           => 'authorization_endpoint',
		        'value'         => 'https://auth.login.yahoo.co.jp/yconnect/v2/authorization',
		        'memo'          => 'Yahoo!ID連携authorization_endpoint',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'YAHOO',
		        'key'           => 'token_endpoint',
		        'value'         => 'https://auth.login.yahoo.co.jp/yconnect/v2/token',
		        'memo'          => 'Yahoo!ID連携token_endpoint',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'YAHOO',
		        'key'           => 'client_id',
		        'value'         => 'dj00aiZpPXpPaUViUnBTOTZoMSZzPWNvbnN1bWVyc2VjcmV0Jng9NjE-',
		        'memo'          => 'Yahoo!ID連携クライアントID',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'YAHOO',
		        'key'           => 'client_secret',
		        'value'         => '2srxqN2wQhQlKENDPkWeNHfuc89KEeEVAZBRI6mQ',
		        'memo'          => 'Yahoo!ID連携シークレット',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'YAHOO',
		        'key'           => 'callback_url',
		        'value'         => 'http://galfie.xsrv.jp/laravel/lohaco/bind/callback',
		        'memo'          => 'Yahoo!ID連携callbak_url',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'YAHOO',
		        'key'           => 'redirect_url',
		        'value'         => 'http://galfie.xsrv.jp/laravel/lohaco/bind/callback',
		        'memo'          => 'Yahoo!ID連携redirect_url',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ],[
                'class'         => 'YAHOO',
		        'key'           => 'include_path',
		        'value'         => '/home/galfie/galfie.xsrv.jp/laravel/app/Services/',
		        'memo'          => 'callbackファイルで使用するinclude_path',
		        'deleted_flg'   => 0,
		        'created_at'    => now(),
		        'updated_at'    => now(),
		        'deleted_at'    => null,
            ]
        ];
        DB::table('const_manager')->truncate();
        DB::table('const_manager')->insert($data);
    }
}
