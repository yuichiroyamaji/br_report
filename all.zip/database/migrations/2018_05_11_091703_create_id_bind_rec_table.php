<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateIdBindRecTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // id_bind_rec（連携記録）テーブルを作成する処理
        Schema::create('id_bind_recs', function(Blueprint $table){
            $table->increments('id')                ->comment('ID');
            $table->string('consumer_id', 255)      ->comment('マイレピID');
            $table->string('one_cp_id', 255)        ->comment('1CPID');
            $table->string('bind_customer_id', 4)   ->comment('連携店舗ID');
            $table->string('bind_user_id', 255)     ->comment('連携ユーザーID');
            $table->string('extra_info_01', 1020)   ->comment('追加保持情報01')   ->nullable();
            $table->string('extra_info_02', 1020)   ->comment('追加保持情報02')   ->nullable();
            $table->string('extra_info_03', 1020)   ->comment('追加保持情報03')   ->nullable();
            $table->string('extra_info_04', 1020)   ->comment('追加保持情報04')   ->nullable();
            $table->string('extra_info_05', 1020)   ->comment('追加保持情報05')   ->nullable();
            $table->integer('deleted_flg')          ->comment('削除フラグ')         ->nullable()  ->default(0);
            $table->timestamp('binded_date')        ->comment('連携日時')         ->default(\DB::raw('CURRENT_TIMESTAMP'));
            $table->timestamp('updated_date')       ->comment('更新日時')         ->default(\DB::raw('CURRENT_TIMESTAMP'));
            $table->timestamp('deleted_date')       ->comment('削除日時')         ->nullable();
            //primary keyの設定
            //$table->primary(['id', 'bind_user_id']);
        });
        
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('id_bind_recs');
    }
}
