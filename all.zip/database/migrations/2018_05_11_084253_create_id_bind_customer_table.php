<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateIdBindCustomerTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // id_bind_customer（連携企業）テーブルを作成する処理
        Schema::create('id_bind_customers', function(Blueprint $table){
            $table->increments('id')                  ->comment('ID');
            $table->string('bind_customer_id', 4)     ->comment('連携店舗ID');
            $table->string('bind_customer_name',255)  ->comment('連携店舗名');
            $table->string('customer_logo_01',255)    ->comment('企業ロゴ01')     ->nullable();
            $table->string('customer_logo_02',255)    ->comment('企業ロゴ02')     ->nullable();
            $table->string('customer_logo_03',255)    ->comment('企業ロゴ03')     ->nullable();
            $table->string('customer_logo_04',255)    ->comment('企業ロゴ04')     ->nullable();
            $table->string('customer_logo_05',255)    ->comment('企業ロゴ05')     ->nullable();
            $table->string('login_logo_01',255)       ->comment('ログインロゴ01')   ->nullable();
            $table->string('login_logo_02',255)       ->comment('ログインロゴ02')   ->nullable();
            $table->string('login_logo_03',255)       ->comment('ログインロゴ03')   ->nullable();
            $table->string('login_logo_04',255)       ->comment('ログインロゴ04')   ->nullable();
            $table->string('login_logo_05',255)       ->comment('ログインロゴ05')   ->nullable();
            $table->integer('display_order')          ->comment('表示順序')      ->nullable();
            $table->integer('status_flg')             ->comment('状態フラグ')      ->nullable()  ->default(1);
            $table->integer('deleted_flg')            ->comment('削除フラグ')      ->nullable()  ->default(0);
            $table->timestamp('binded_date')          ->comment('連携日時')      ->default(\DB::raw('CURRENT_TIMESTAMP'));
            $table->timestamp('updated_date')         ->comment('更新日時')      ->default(\DB::raw('CURRENT_TIMESTAMP'));
            $table->timestamp('deleted_date')         ->comment('削除日時')      ->nullable();
            //primary keyの設定
            //$table->primary(['id', 'bind_customer_id']);
        });
        
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('id_bind_customers');
    }
}
