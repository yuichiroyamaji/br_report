<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateConstManagerTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('const_manager', function (Blueprint $table) {
            $table->increments('id')           ->comment('ID');
            $table->string('class', 255)    ->comment('区分名');
            $table->string('key', 255)         ->comment('キー');
            $table->string('value', 255)       ->comment('値');
            $table->string('memo', 255) ->comment('説明');
            $table->integer('deleted_flg')     ->comment('削除フラグ')->nullable()->default(0);
            $table->timestamp('created_at')    ->comment('作成日時')->default(\DB::raw('CURRENT_TIMESTAMP'));
            $table->timestamp('updated_at')    ->comment('更新日時')->default(\DB::raw('CURRENT_TIMESTAMP'));
            $table->timestamp('deleted_at')  ->comment('削除日時')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('const_manager');
    }
}
