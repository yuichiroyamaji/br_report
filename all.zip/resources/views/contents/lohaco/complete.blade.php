<!-- resources/views/tasks.blade.php -->



        <img class="mb-4" src="img/myrepi_logo.png" alt="" width="140" height="60">
        <h4 class="h4 mb-3 font-weight-normal">{{$company}}ID連携完了ページ</h4>
        <h1 class="h1 mb-3 font-weight-normal">{{$message}}</h1>
        @if($errors->any())
        <h4>{{$errors->first()}}</h4>
        @endif
        <div>リンクなどを表示</div>
        <p class="mt-5 mb-3 text-muted">&copy; 2017-2018</p>
    <!-- TODO: 現在のタスク -->
