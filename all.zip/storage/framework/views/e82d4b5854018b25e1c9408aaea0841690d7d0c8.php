<!-- resources/views/tasks.blade.php -->



        <form action="/laravel/lohaco/bind" method="POST" class="form-signin">
            <?php echo e(csrf_field()); ?>

            <img class="mb-4" src="img/myrepi_logo.png" alt="" width="140" height="60">
            <!-- バリデーションエラーの表示 -->
            <?php if($errors->any()): ?>
            <h4><?php echo e($errors->first()); ?></h4>
            <?php endif; ?>
            <h1 class="h4 mb-3 font-weight-normal">マイレピの登録メールアドレス･パスワードを入力してください</h1>
            <label for="inputEmail" class="sr-only">ﾒｰﾙｱﾄﾞﾚｽ</label>
            <input type="email" id="email" class="form-control" name="email" placeholder="Email address" value="tester12@yopmail.com" required autofocus>
            <label for="inputPassword" class="sr-only">パスワード</label>
            <input type="password" id="password" class="form-control" name="password" placeholder="Password" value="test1234" required>
            <div><a>forgot Password?</a></div>
            <button class="btn btn-lg btn-primary btn-block" type="submit">送信</button>
            <p class="mt-5 mb-3 text-muted">&copy; 2017-2018</p>
        </form>

    <!-- TODO: 現在のタスク -->
