<?php

namespace App\Services;
use App\Exceptions;
use Log;
use DB;
use Exception;

class CreateMsgService
{
    public static function createErrMsg($error)
    {        
        $uuid = uniqid('');        
        session('consumer_id') ? $user = session('consumer_id') : $user = 'ログイン前状態';   
        $log_msg = '[エラー特定コード] '.$uuid.' [ユーザー] '.$user.' [エラー内容] '.$error;
        $user_msg = 'システムエラーが発生しました。しばらく経ってから再度お試し下さい。'."\n".'[エラー特定コード] '.$uuid;
        return array('log_msg' => $log_msg, 'user_msg' => $user_msg);
    }
}