<?php

namespace App\Services;
use App\Exceptions;
use App\Models\ConstManager;
use Log;
use DB;
use Exception;
use App\Services\CreateMsgService;
use Request;

class GrsApiAccessService
{
    public static function access($api_url, $api_method, $basic_user, $basic_pass, $api_contype, $get_param=null, $request_body=null)
    {        
        Log::info($api_url);
        //CURLのPROXY設定値を外部定義テーブルから取得
        $const_vals = DB::transaction(function(){
            $result = \App\Models\ConstManager::where('class', 'CURL')->get();
            return $result;
        });
        //設定値の代入
        foreach($const_vals as $const_val){
            if($const_val->key == 'curlopt_timeout'){$curlopt_timeout = $const_val->value;}
            if($const_val->key == 'curlopt_proxy'){$curlopt_proxy = $const_val->value;}
            if($const_val->key == 'curlopt_proxyport'){$curlopt_proxyport = $const_val->value;}
        }
        //GETの場合はURLにパラメーターを追加(GRSの場合は「?」は要らない)
        // $api_url = ($get_param != '') ? $api_url.'?'.$get_param : $api_url;
        $api_url = ($get_param != '') ? $api_url.$get_param : $api_url;
        //Basic認証生成
        $basic_auth = sprintf('Authorization: Basic %s', base64_encode(sprintf('%s:%s', $basic_user, $basic_pass)));
        //curlの開始
        $curl = curl_init();        
        // オプション設定
        $options = array(
            CURLOPT_URL              => $api_url,
            CURLOPT_CUSTOMREQUEST    => $api_method,
            CURLOPT_RETURNTRANSFER   => true,
            CURLOPT_HTTPPROXYTUNNEL  => true,
            CURLOPT_SSL_VERIFYPEER   => false,
            CURLOPT_TIMEOUT          => $curlopt_timeout,
            CURLOPT_PROXY            => $curlopt_proxy,
            CURLOPT_PROXYPORT        => $curlopt_proxyport,
            CURLOPT_HTTPHEADER       => [$basic_auth, $api_contype]
        );
        //POSTの場合はリクエストbodyを追加
        if($request_body!=null){
            $params_option = array(
                CURLOPT_POSTFIELDS => ($request_body),
            );
            $options = $options + $params_option;
        }
        //オプションの設置
        curl_setopt_array ($curl, $options);
        //curl実行/リスポンスの代入
        $response = curl_exec($curl);
        //リクエストに失敗した場合
        if($response == false) {
           $error          = curl_error($curl);
           $error_no       = curl_errno($curl);
           $error_message  = "curl_errno={$error_no}: {$error}";
           curl_close($curl);
           throw new Exception($error_message);
           return;
        }
        //Uniodeエスケープを元に戻す(ログ出力用)
        $unicode_decode_json = json_encode(json_decode($response), JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
        //Uniodeエスケープを元に戻し、配列に変換する（返り値用）
        $unicode_decode_array = json_decode(json_encode(json_decode($response), JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
        //（curlの戻り値に含まれる日本語がunicodeエスケープされ文字表示されないため一度decodeし、エスケープ処理なしで再度encodeし、それをまたdecodeしている）

        // レスポンスデータの解析
        $http_code      = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $header_size    = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
        $response_header    = substr($unicode_decode_json, 0, $header_size);
        //bodyには個人情報が含まれるためログに残さない
        // $body           = substr($unicode_decode_json, $header_size);  
        $user = session('consumer_id') ? session('consumer_id') : $user = 'not login';
        Log::info('[REQUEST] {ip} '.Request::ip().' {user} '.$user.' {url} '.$api_url.' {method} '.$api_method.' {req_body} '.$request_body.' {http_code} '.$http_code.' {response} '.$response_header);
        curl_close($curl);
        return $unicode_decode_array;
    }

}