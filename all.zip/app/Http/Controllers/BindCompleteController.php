<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Rules\JANcode;
use App\Http\Controllers\Controller,Session;
use App\Models\IdBindCustomer;
use App\Models\IdBindRec;
use DB;
use Exception;
use App\Services\CreateMsgService;
use Log;

class BindCompleteController extends Controller
{
    
    public function index(){
      return 'here is an index';
      
    }

    public static function lohacoBindComplete(Request $request){
      $company = 'lohaco';
      $access_token = $request->old('access_token');
      $refresh_token = $request->old('refresh_token');
      //DB登録項目の準備
      //リダイレクトでの呼出のためフラッシュデータから値を取得  
      $bind_user_id = $request->old('bind_user_id');
      $extra_info_01 = 'ACCESS_TOKEN: '.$access_token;
      $extra_info_02 = 'REFRESH_TOKEN: '.$refresh_token;
      $extra_info_03 = null;
      $extra_info_04 = null;
      $extra_info_05 = null;
      //DB登録
      try{
        $msg = self::dbRegister($company, $bind_user_id, $extra_info_01, $extra_info_02, $extra_info_03, $extra_info_04, $extra_info_05);
      }catch(Exception $e){
        $msg = CreateMsgService::createErrMsg($e->getMessage());
        Log::error($msg['log_msg']);
        return redirect('/lohaco/myrepi/login')->withErrors($msg['user_msg']);
      }
      //登録完了ページを表示
      return view('contents.lohaco.complete')->with(['company' => 'lohaco', 'message'  => $msg]);
    }


    public function cainzBindComplete(Request $request){
      //CAINZ IDのJANコードチェック
    	$this->validate($request, [
    		'cainz_id' => ['required',new JANcode],
    	]);
      $company = 'cainz';
    	//DB登録項目の準備
    	$bind_user_id = $request -> {'cainz_id'};
      $extra_info_01 = null;
      $extra_info_02 = null;
      $extra_info_03 = null;
      $extra_info_04 = null;
      $extra_info_05 = null;
      //DB登録
      try{
        $msg = self::dbRegister($company, $bind_user_id, $extra_info_01, $extra_info_02, $extra_info_03, $extra_info_04, $extra_info_05);
      }catch(Exception $e){
        $msg = CreateMsgService::createErrMsg($e->getMessage());
        Log::error($msg['log_msg']);
        return redirect()->back()->withErrors($msg['user_msg']);
      }
      //登録完了ページを表示
      return view('contents.cainz.complete')->with(['company' => 'cainz', 'message'  => $msg]);	
    }


    public static function dbRegister($company, $bind_user_id, $extra_info_01, $extra_info_02, $extra_info_03, $extra_info_04, $extra_info_05){

      Session::put('consumer_id', 'consumer_id_001');
      Session::put('one_cp_id', 'one_cp_id_001');
      //セッションからマイレピIDと1CPIDを取得
      $consumer_id = Session::get('consumer_id');
      $one_cp_id = Session::get('one_cp_id');
      DB::beginTransaction();
      try{
        //企業名から連携企業IDを取得
        $bind_customer_id = \App\Models\IdBindCustomer::where('bind_customer_name', $company)->value('bind_customer_id');
        //同じマイレピIDで指定の企業と過去に連携しているか確認
        $existence = \App\Models\IdBindRec::where('consumer_id', $consumer_id)->where('one_cp_id', $one_cp_id)->where('bind_customer_id', $bind_customer_id)->exists();
        //連携していたら過去のデータに削除フラグを立てて、「更新が完了しました」のメッセージを返す
        if($existence){
          \App\Models\IdBindRec::where('one_cp_id', $one_cp_id)->where('consumer_id', $consumer_id)->where('bind_customer_id', $bind_customer_id)->where('deleted_flg', 0)->update(['deleted_flg' => 1, 'deleted_date' => now()]);
          $msg = '更新が完了しました!';
        //連携していなかったら「登録が完了しました」のメッセージを返す
        }else{
          $msg = '登録が完了しました!'; 
        }
        //insert実行
        $insert_result = \App\Models\IdBindRec::create([
          'consumer_id'        => $consumer_id,
          'one_cp_id'          => $one_cp_id,
          'bind_customer_id'   => $bind_customer_id, 
          'bind_user_id'       => $bind_user_id,
          'extra_info_01'      => $extra_info_01,
          'extra_info_02'      => $extra_info_02,
          'extra_info_03'      => $extra_info_03,
          'extra_info_04'      => $extra_info_04,
          'extra_info_05'      => $extra_info_05,
          'deleted_flg'        => 0,
          'binded_date'        => now(),
          'updated_date'       => now(),
          'deleted_date'       => null
        ]);
        DB::commit();
      }catch(\Exception $e){
        DB::rollback ();
        throw new Exception($e);
      }
      return $msg;
    }
}
