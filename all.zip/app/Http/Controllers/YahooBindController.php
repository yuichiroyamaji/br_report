<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\CreateMsgService;
use App\Http\Controllers\Controller,Session;
use DB;
use Log;
use File;
use Exception;

class YahooBindController extends Controller
{
    public function index(){

    }

    public function showYahooLoginPage(){
    	DB::beginTransaction();
        try{
            //YAHOO関連の設定値を外部定義ファイルから取得
            $const_vals = \App\Models\ConstManager::where('class', 'YAHOO')->get();
            DB::commit();
        }catch(\Exception $e){
           DB::rollback ();
           $msg = CreateMsgService::createErrMsg($e->getMessage());
           Log::error($msg['log_msg']);
           return redirect()->back()->withErrors($msg['user_msg']);
        }
		//設定値の代入
		foreach($const_vals as $const_val){
            if($const_val->key == 'client_id'){$client_id = $const_val->value;}
            if($const_val->key == 'redirect_url'){$redirect_url = $const_val->value;}
            if($const_val->key == 'authorization_endpoint'){$authorization_endpoint = $const_val->value;}
        }
        //リクエストパラメーターを作成
    	$request_parameters = [
		    'response_type' => 'code',
		    'client_id' => $client_id,
		    'redirect_uri' => $redirect_url,
		    'scope' => 'openid'
		    // 'scope' => 'openid email profile address'
		];
		$query = [];
		foreach ($request_parameters as $key => $value) {
		    $query[] = $key . "=" . $value;
		}
		//Yahooの Authorization ページへリダイレクト		
		header(sprintf("Location:%s?%s", $authorization_endpoint, implode("&", $query)));
    	return;
	}

	public function callback(){
		DB::beginTransaction();
        try{
            //YAHOO関連の設定値を外部定義ファイルから取得
            $const_vals = \App\Models\ConstManager::where('class', 'YAHOO')->get();
            DB::commit();
        }catch(\Exception $e){
           DB::rollback ();
           $msg = CreateMsgService::createErrMsg($e->getMessage());
           Log::error($msg['log_msg']);
           return redirect()->back()->withErrors($msg['user_msg']);
        }
		//設定値の代入
		foreach($const_vals as $const_val){
			if($const_val->key == 'include_path'){$include_path = $const_val->value;}
            if($const_val->key == 'token_endpoint'){$token_endpoint = $const_val->value;}
            if($const_val->key == 'client_id'){$client_id = $const_val->value;}
            if($const_val->key == 'client_secret'){$client_secret = $const_val->value;}
            if($const_val->key == 'redirect_url'){$redirect_url = $const_val->value;}
        }
		set_include_path($include_path);
		\File::requireOnce('Net/URL2.php');
		\File::requireOnce('HTTP/Request2.php');
		//コードをセット
		$code = $_REQUEST['code'];
		//オプションをセット
		$http_options = [
		    'protocol_version' => '1.1',
		    'connect_timeout' => '300',
		    'timeout' => '300',
		    'follow_redirects' => true,
		    'max_redirects' => 3,
		    'ssl_verify_peer' => false
		];
		$req = new \HTTP_Request2($token_endpoint, \HTTP_Request2::METHOD_POST, $http_options);
		//ヘッダをセット
		$req->setHeader('Connection', 'keep-alive');
		$req->setHeader('Content-Type', 'application/x-www-form-urlencoded');
		$req->setHeader('Accept-Charset', 'UTF-8');
		 //パラメータをセット
		$request_parameter = [
		    'code' => $_REQUEST['code'],
		    'client_id' => $client_id,
		    'client_secret' => $client_secret,
		    'redirect_uri' => $redirect_url,
		    'grant_type' => 'authorization_code'
		];
		foreach ($request_parameter as $key => $value) {
		    $req->addPostParameter($key, $value);
		}
		//リクエスト
		try {
		    $res = $req->send();
		    if ($res->getStatus() != 200) {
		        throw new Exception($e);
		        return;
		    }
		    $responses = json_decode($res->getBody());
		    //ユーザー識別子(sub),アクセス/リフレッシュトークンを取得
		    list($client_id_signature, $jwt_encoded) = explode(".", $responses->id_token);
		    $jwt = json_decode(base64_decode($jwt_encoded));
		    $bind_user_id = $jwt->sub;
		    $access_token = $responses->access_token;
		    $refresh_token = $responses->refresh_token;
		} catch (\Exception $e) {
		    $msg = CreateMsgService::createErrMsg($e->getMessage());
            Log::error($msg['log_msg']);
            return redirect()->back()->withErrors($msg['user_msg']);
		}
		return redirect('/lohaco/bind/complete')->withInput(['bind_user_id'=>$bind_user_id, 'access_token'=>$access_token, 'refresh_token'=>$refresh_token]);
	}

			
}
