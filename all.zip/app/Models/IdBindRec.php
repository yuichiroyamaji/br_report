<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IdBindRec extends Model
{
    public $timestamps = false;
    protected $table = 'id_bind_recs';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
    	    'consumer_id',
    	    'one_cp_id',
            'bind_customer_id',
            'bind_user_id',
            'extra_info_01',
            'extra_info_02',
            'extra_info_03',
            'extra_info_04',
            'extra_info_05',
            'deleted_flg',
            'binded_date',
            'updated_date',
            'deleted_date',
    ];
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    /*
    protected $hidden = [
            'myrepi_id', 
            'bind_user_id',
            'access_token',
            'refresh_token',
            'extra_info_01',
            'extra_info_02',
            'extra_info_03',
            'extra_info_04',
            'extra_info_05',
    ];
    */    
}
