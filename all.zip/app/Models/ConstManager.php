<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ConstManager extends Model
{
    public $timestamps = false;
    protected $table = 'const_manager';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'class',
        'key',
        'value',
        'memo',
        'deleted_flg',
        'created_at',
        'updated_at',
        'deleted_at',
    ];
}
