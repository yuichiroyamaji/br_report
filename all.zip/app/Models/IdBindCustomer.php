<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IdBindCustomer extends Model
{
    public $timestamps = false;
    protected $table = 'id_bind_customers';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'bind_customer_id',
        'bind_customer_name',
        'customer_logo_01',
        'customer_logo_02',
        'customer_logo_03',
        'customer_logo_04',
        'customer_logo_05',
        'login_logo_01',
        'login_logo_02',
        'login_logo_03',
        'login_logo_04',
        'login_logo_05',
        'display_order',
        'status_flg',
        'deleted_flg',
        'binded_date',
        'updated_date',
        'deleted_date',
    ];
}
